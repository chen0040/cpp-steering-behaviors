/*
 *  cApp.cpp
 *  Kore-Engine
 *
 *  Created by Sean Chapel on 11/15/05.
 *  Copyright 2005 Seoushi Games. All rights reserved.
 *
 */

#include "cApp.h"

namespace Kore
{
	cApp::cApp()
	{
	}
	
	cApp::~cApp()
	{
	}
}
